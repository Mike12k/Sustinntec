<?php
$self = $_SERVER['PHP_SELF'];
header("refresh:180; url=$self");

include("db_temp.php");
include("phpgraphlib/phpgraphlib.php");

$graph=new PHPGraphLib(1140,380);
$dataArray=array();
$date=strftime("%Y-%m-%d", time());


//$date="2018-02-10";
//get data from database

$sql="SELECT temperature, DATE_FORMAT(fecha, '%H:%i') as hora FROM temp_admin WHERE DATE(fecha)='$date'";
$result = mysql_query($sql) or die('Query failed: ' . mysql_error());

if ($result) {
 while ($row = mysql_fetch_assoc($result)) {
 $time=$row['hora'];
 $te=$row['temperature'];
 $temp=substr($te, 0, 2);
 //add to data areray
 $dataArray[$time]=$temp;
  }
}

$graph->addData($dataArray);
$graph->setTitle('Registro diario de temperatura, Chiller Administracion - SENSOR: 192.168.0.138');
$graph->setBars(false);
$graph->setLine(true);
$graph->setDataPoints(true);
$graph->setupYAxis(10, "#C17884");
$graph->setupXAxis(10, "#C17884");
$graph->setLineColor('#747FFE', 'green');
$graph->setDataPointColor('blue');
$graph->setDataValues(true);
$graph->setDataValueColor('maroon');
$graph->setGoalLine(.0025);
$graph->setGoalLineColor('red');
$graph->createGraph();
?>