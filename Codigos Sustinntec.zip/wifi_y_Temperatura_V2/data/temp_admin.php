<?php
include("dbT.php");
$valor=$_GET['valor'];
mysql_query("INSERT INTO temp_admin(temperature) VALUES('$valor')");

?>